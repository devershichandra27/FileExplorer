#include <iostream>

using namespace std;

int main(int argc, char const *argv[])
{
    cout << "Devershi Chandra" << endl;
    cout << "\033[2J\033[1;1H" << endl;
    cout << "Manu" << endl;
    cout << "Another text" << endl;
    getchar();
    return 0;
}
